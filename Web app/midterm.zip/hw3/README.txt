DEPENDENCY:
    python3,
    numpy,
    matplotlib.

USE CASE:
    open a terminal, and type in:
    python curveFitting.py 

DATASET:
    there are 10 datasets for runtest, by default, this program would run on all of them,

CUSTOMIZE:
    there are three parameters for the curve fitting,
    call curfit(traindata,alpha,beta,M) to run the program,
    by default, alpha=0.005, beta=2, M=9.

OUTPUT:
    print out the absolute error and relative error for each stock,
    and store in result.csv

